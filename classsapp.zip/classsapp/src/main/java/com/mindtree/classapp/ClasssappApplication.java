package com.mindtree.classapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClasssappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClasssappApplication.class, args);
	}

}
