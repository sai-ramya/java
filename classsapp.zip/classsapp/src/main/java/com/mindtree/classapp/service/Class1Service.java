package com.mindtree.classapp.service;

import com.mindtree.classapp.dto.Class1Dto;

public interface Class1Service {

	/**
	 * @param class1Dto
	 * @return insertion status for class
	 */
	public String addClass(Class1Dto class1Dto);

}
